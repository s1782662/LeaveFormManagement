
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","LeaveFormManagement\\Calendar\\Calendar"],["c","LeaveFormManagement\\Calendar\\InterfaceCalendar"]];
